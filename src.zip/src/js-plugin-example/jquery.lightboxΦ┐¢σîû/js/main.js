require.config({

    paths:{
        jquery:"/yingda/src/javascript/lib/jquery.min",
        jsviews:"/yingda/src/javascript/jsviews"
    }

});
require(['jquery','bootstrap','jquery.lightbox3'],function($){

});