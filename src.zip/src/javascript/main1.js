/**
 * Created by Administrator on 2014/8/8.
 */
require.config({
    baseUrl:"../javascript",
    paths:{
        jquery:"lib/jquery.min"
    }
});

require(['jquery','jquery.lightbox'],function($){

})